import type { Metadata } from "next";
import localFont from "next/font/local";
import "./globals.css";
import WalletAdapterProvider from "./WalletAdapterProvider";
import { Toaster } from "@/components/ui/toaster";
import { siteConfig } from "@/config/site-config";

const geistSans = localFont({
	src: "./fonts/GeistVF.woff",
	variable: "--font-geist-sans",
	weight: "100 900",
});
const geistMono = localFont({
	src: "./fonts/GeistMonoVF.woff",
	variable: "--font-geist-mono",
	weight: "100 900",
});

export const metadata: Metadata = siteConfig;

export default function RootLayout({
	children,
}: Readonly<{
	children: React.ReactNode;
}>) {
	return (
		<html lang="en">
			<WalletAdapterProvider>
				<body
					className={`${geistSans.variable} ${geistMono.variable} antialiased`}
				>
					{children}
					<Toaster />
				</body>
			</WalletAdapterProvider>
		</html>
	);
}
